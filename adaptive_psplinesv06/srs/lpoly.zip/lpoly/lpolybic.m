function [mhat,varmhat]=lpolybic(x,y,h,xgrid,order,p,covy,ridgecoef,iresvar) ;
%     lpolybic  --- Modified from lpolybiv
%
%     last revised 10/11/96
%
%     Estimates the derivative of a regression function (including the
%        0th derivative) by local polynomial fits on a grid called "xgrid".
%
%     x = independent variable  (dim = n by 2)
%
%     y = dependent variable  (dim = n)
%
%     xgrid = points at which the fit is calculated  (dim = m by 2)
%
%     h = bandwidth matrix --- bandwidth at i-th xgrid point is
%         h(i) (If h is a scalar then it is expanded to be a constant
%         m vector.)
%
%     order = 1 estimate the function itself
%             2 estimate 1st der. wrt x1
%             3 estimate 1st der. wrt x2
%             4 estimate 2nd der. wrt x1
%             5 estimate 2nd der. wrt x1
%             4 estimate mixed 2nd der. wrt x1 and x2
%
%     p = degree of the local polynomials 
%
%     covy = estimated covariance matrix of the y's  (needed to calculate
%            varmhat and resvar)
%
%     ridgecoef: set equal to 0 unless local ridge regression is desired
%
%     iresvar: if equal to 1, then variance of the residuals is calculated.
%	       Should be 0 if xgrid is not equal to x.
%              The variance of the residuals is resvar which is global
%
%     This implementation uses the epan. kernel with support the unit circle.
%
%     returns:
%
%     mhat = the estimated order-th derivative of E(y|x) at each point 
%         on xgrid.  (m dimensional)
%
%     varmhat = the estimate of the variance of mhat (m dimensional) (covy
%               is used to calculate varmhat)
%
%     
%  USAGE: [mhat,varmhat]=lpolybic(x,y,h,xgrid,order,p,covy,ridgecoef,iresvar) ;
%
%
%     calls the following functions:  rows, cols	
%
%     GLOBAL: resvar
%
%
global resvar ;

	if rows(y) == 1 ;
	y = y' ;
	end ;

	if rows(x) < cols(x) ; 
	x = x' ; 
	end ;

n = rows(x) ;
   
coef = [ 1 1 1 2 2 1] ;

m = rows(xgrid) ;

	
	if rows(h) == 1 ;
	h = h*ones(m,1) ;
	end ;	

mhat = zeros(m,1) ;   % initialize vectors for storage
varmhat = mhat ;
yyhatcov = mhat ;
resvar = mhat ;
   
	for i=1:m ;
	xc = [(x(:,1) - xgrid(i,1)) (x(:,2) - xgrid(i,2))] ;
	dist = (xc(:,1)./h(i)).^2 +  (xc(:,2)./h(i)).^2 ;
	w = (1 - dist)   .*(dist < 1) ;
	xm = ones(n,1) ;
		if p >= 1; xm = [xm xc] ;end ;
		if p == 2 ;
		xm = [xm xc(:,1).^2 xc(:,2).^2 xc(:,1).*xc(:,2)] ;
		end ;   
	
	w2 = w*ones(1,cols(xm)) ;
        xw = w2.*xm ;
	
	Ridge = ridgecoef*eye(cols(xm)) ;
	Ridge(1,1) = 0 ;

		if p == 2 ;
		Ridge(2,2) = 0 ;Ridge(3,3) = 0 ;
		end ;
		xwx = (xm'* xw + Ridge) ;

		if  cond(xwx) >= 1e18;
		varmhat(i)=1e14;mhat(i)=-9999;
		else;
		ixwx=inv(xwx) ;
		ixwxxw = ixwx*(w2.*xm)' ;
		beta = ixwxxw * y ;
       		cov = ixwx * (xw'* covy *xw) * ixwx;
		mhat(i) =  beta(order)*coef(order) ;
		varmhat(i) = (coef(order))^2 * cov(order,order) ;
			if iresvar == 1 ;
			yyhatcov(i) = ixwxxw(1,:)*covy(:,1) ;
			resvar(i) = covy(i,i) - 2*yyhatcov(i) + varmhat(i) ;
		end ;
		end;

	end ;
	
