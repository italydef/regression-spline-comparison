function [f,var,hat,gcv]=lpolydb(x,y,h,xgrid,order,k,varyfactor,ridgecoef) ;
%     lpolydb  --- Modified from lpolyd
%
%     last revised 11/5/97
%
%     Estimates the derivative of a regression function (including the
%        0th derivative) by local polynomial fits on a grid called "xgrid".
%
%		THE FOLLOWING INPUTS ARE REQUIRED
%     x = independent variable  (dim = n)
%     y = dependent variable  (dim = n)
%     h = bandwidth vector --- bandwidth at i-th xgrid point is
%         h(i) (If h is a scalar then it is expanded to be a constant
%         m-vector.) (dim h = 1 or m)
%
%
%		THE FOLLOWING INPUTS ARE OPTIONAL
%     xgrid = points at which the fit is calculated  (dim = m)(DEFAULT is x)
%     order = order of the derivative being estimated (Use order = 0 to
%             estimate the regression function) (scalar) (DEFAULT is 0)
%     k = degree of the local polynomials is (order + k) [So, k=1 for
%         local linear fits to estimate a regression function.] (scalar)
%	(DEFAULT is 1)
%     ridgecoef: for local ridge regression (scalar) (DEFAULT is 0)
%     varyfactor = variance of y is a 
%       local constant (typically local constant= var. of raw-data response) 
%       times varyfactor.
%       If the data have not been binned, then typically varyfactor is
%       a vector of 1's.  If varyfactor is a scalar then it is expanded
%       to an n-dim vector. (dim of varyfactor = 1 or n) (DEWFAULT is 1)
%
%
%     This implementation uses the epan. kernel with support (-1,1).
%
%     returns:
%     f = the estimated order-th derivative of E(y|x) at each point 
%         on xgrid.  (m dimensional)
%     var = the estimate of the variance of this estimate divided by sigma2,
%           where sigma2 is the variance of the y's. (m dimensional)
%	hat = hat matrix diagonals
%	gcv = generalized cross-validation statistic
%               
%`
% USAGE: [f,var,hat,gcv]=lpolydb(x,y,h,xgrid,order,k,varyfactor,ridgecoef) ;
%	f = lpolydb(x,y,h) is the minimum calling statement.
%
%	Copyright: David Ruppert
%
if nargin < 8 ;
ridgecoef = 0 ;
end ;
if nargin < 7 ;
varyfactor = 1 ;
end ;
if nargin < 6 ;
k = 1 ;
end ;
if nargin < 5 ;
order = 0 ;
end ;
if nargin < 4;
xgrid = x ;
end ;

n = size(x,1) ;
kk= order + k ;
m = size(xgrid,1) ;

    if size(h,1) == 1 ;
    h = h*ones(m,1) ;
    end ;

    if size(varyfactor,1) == 1 ;
    varyfactor = varyfactor*ones(n,1) ;
    end ;

f = ones(m,1) ;
var = ones(m,1) ;
ihat = 0 ;
	if size(xgrid) == size(x) ;
		if xgrid == x ;
		ihat = 1 ;
		end ;
	end ;

if ihat == 1 ;
hat = ones(m,1) ;
else ;
hat = [] ;
end ;
	if order > 0 ;
	factorder = prod(1:order) ;
	else ;
	factorder = 1 ;
	end ;
   
    for i=1:m ;
    xc = x - xgrid(i) ;
    w = (3/4)*(1 - (xc/h(i)).^2).*(abs(xc/h(i)) < 1) ;
    w= w./varyfactor ;
    xm = ones(n,1) ;
    
        for jj = 1:kk ;
        xm = [xm,(xc.^jj)] ;
        end ;
    ridgematrix = zeros(kk+1,kk+1) ;
    ridgematrix(kk+1,kk+1) = ridgecoef ;

    w2 = (w)*ones(1,size(xm,2)) ;
    xw = w2.*xm ;
    xwx = xm' * xw + ridgematrix ;
           if  rcond(xwx) <= 1e-20;
	var(i)=1e14;f(i)=-999999;
	else;
        ixwx = inv(xm'* (xw) + ridgematrix) ;
	beta = ixwx * xw' * y ;
	f(i) =  beta(order+1)*fact(order) ;
	if ihat == 1 ;
	hat(i) = fact(order)*ixwx(1+order,:)*xw(i,:)' ;
	end ;
	cov = ixwx *  xw' * ( (varyfactor*ones(1,size(xw,2))) .*xw) * ixwx;
 	var(i) = (fact(order))^2 * cov(order+1,order+1) ;
        end ;
    end ;

if ihat==1;
gcv = mean((y-f).^2) / ( 1 - sum(hat)/n)^2 ;
else ;
gcv = [];
end ;
