function [f,cv]=lpolydb(x,y,h,k,induse) ;
%	lpolydb  --- Modified from lpolyd
%
%		INPUT (Required)
%	x = independent variable  (dim = n)
%	y = dependent variable  (dim = n)
%	h = bandwidth vector --- bandwidth at x_i is
%         h(i) (If h is a scalar then it is expanded to be a constant
%         m-vector.) (dim h = 1 or n as input, but dim h = n during
%	  use)
%
%		INPUT (Optional)
%	k = degree of the local polynomials (default = 1)
%	induse = indicator of those indices of x used to calculate f
%		and CV (default = ones(n,1)).  This vector is automatically
%		converted to a logical array by lpolycv.  The purpose
%		of induse is for calculating CV local for local spans
%
%	This implementation uses the epan. kernel with support (-1,1).
%
%	returns:
%	f = the estimated regression function at each x (dim = n)
%	cv = cv statistic (dim = 1)
%               	
%	USAGE: [f,cv]=lpolydb(x,y,h,k) ;
%	Last edit: May 3, 1998
%
%	Copyright: David Ruppert
%
n = size(x,1) ;

if nargin < 4 ;
	k=1 ;
end ;

if nargin < 5 ;
	induse = ones(n,1) ;
end ;

    if size(h,1) == 1 ;
    h = h*ones(n,1) ;
    end ;

induse = (induse == 1) ;
f = ones(n,1) ;
for i=1:n ;
	if induse(i) == 1 ;
    		ind = ((1:n)' ~= i*ones(n,1)) & ( (abs(x-x(i)) < h(i))) ;
			% indicator of x's within one bandwidth and not equal
			% to x(i)
			%
		    xc = x(ind) - x(i) ;
		    w = (3/4)*(1 - (xc/h(i)).^2) ;
		    xm = ones(size(xc,1),1) ;
	    
		for j = 1:k ;
			       xm = [xm,(xc.^j)] ;
		end ;
	   
		w2 = w*ones(1,size(xm,2)) ;
		xw = w2.*xm ;
		xwx = xm' * xw  ;
		ixwx = inv(xm'* xw) ;
		beta = ixwx * xw' * y(ind) ;
		f(i) =  beta(1) ;
	end ;
end ;
cv = mean((y(induse)-f(induse)).^2) ;
