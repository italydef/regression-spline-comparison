function [f,var]=lpolybiv(x,y,h,xgrid,order,p,varyfactor,ridgecoef,iresvar) ;
%     lpolybiv  --- Modified from lpolyd
%
%     last revised 12/7/95
%
%     Estimates the derivative of a regression function (including the
%        0th derivative) by local polynomial fits on a grid called "xgrid".
%
%     x = independent variable  (dim = n by 2)
%     y = dependent variable  (dim = n)
%     xgrid = points at which the fit is calculated  (dim = m by 2)
%     h = bandwidth matrix --- bandwidth at i-th xgrid point is
%         h(i) (If h is a scalar then it is expanded to be a constant
%         m vector.)
%
%     order = 1 estimate the function itself
%             2 estimate 1st der. wrt x1
%             3 estimate 1st der. wrt x2
%             4 estimate 2nd der. wrt x1
%             5 estimate 2nd der. wrt x1
%             4 estimate mixed 2nd der. wrt x1 and x2
%
%     p = degree of the local polynomials 
%
%     varyfactor: set equal to 1 unless using binned data
%
%     ridgecoef: set equal to 0 unless local ridge regression is desired
%
%      iresvar: if equal to 1, then variance of the residuals is calculated
%		should be 0 if xgrid is not equal to x
%
%     This implementation uses the epan. kernel with support the unit circle.
%
%     returns:
%     f = the estimated order-th derivative of E(y|x) at each point 
%         on xgrid.  (m dimensional)
%     var = the estimate of the variance of this estimate divided by sigma2,
%           where sigma2 is the variance of the y's. (m dimensional)
%
%     
%   USAGE: [f,var]=lpolybiv(x,y,h,xgrid,order,p,varyfactor,ridgecoef,iresvar) ;
%
%
%     calls the following functions:  fact (factorial), rows, cols	
%
%    GLOBAL: resvar
%
%
global resvar ;

	if rows(y) == 1 ;
	y = y' ;
	end ;

	if rows(x) < cols(x) ; 
	x = x' ; 
	end ;

n = rows(x) ;
    if rows(varyfactor) == 1 ;
    varyfactor = varyfactor*ones(n,1) ;
    end ;

coef = [ 1 1 1 2 2 1] ;

m = rows(xgrid) ;

	
	if rows(h) == 1 ;
	h = h*ones(m,1) ;
	end ;	

f = ones(m,1) ;
var = f ;
yyhatcov = f ;
resvar = f ;
   
	for i=1:m ;
	xc = [(x(:,1) - xgrid(i,1)) (x(:,2) - xgrid(i,2))] ;
	dist = (xc(:,1)./h(i)).^2 +  (xc(:,2)./h(i)).^2 ;
	w = (1 - dist)   .*(dist < 1) ;
	xm = ones(n,1) ;
		if p >= 1; xm = [xm xc] ;end ;
		if p == 2 ;
		xm = [xm xc(:,1).^2 xc(:,2).^2 xc(:,1).*xc(:,2)] ;
		end ;   
	
	
	w2 = w*ones(1,cols(xm)) ;
        xw = w2.*xm ;
	
	Ridge = ridgecoef*eye(cols(xm)) ;
	Ridge(1,1) = 0 ;

		if p == 2 ;
		Ridge(2,2) = 0 ;Ridge(3,3) = 0 ;
		end ;
		xwx = (xm'* xw + Ridge) ;

		if  cond(xwx) >= 1e12;
		var(i)=1e14;f(i)=-9999;
		else;
		ixwx=inv(xwx) ;
		ixwxxw = ixwx*(w2.*xm)' ;
		beta = ixwxxw * y ;
       		cov = ixwx *  xw' * ( (varyfactor*ones(1,cols(xw))) .*xw)*ixwx;
		f(i) =  beta(order)*coef(order) ;
		var(i) = (coef(order))^2 * cov(order,order) ;
			if iresvar == 1 ;
			yyhatcov(i) = ixwxxw(1,i) ;
			resvar(i) = 1 - 2*yyhatcov(i) + var(i) ;
		end ;
		end;

	end ;
	
