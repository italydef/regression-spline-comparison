function varsmooth=lpolyvar(x,y,hm,hv,xgrid,k,varyfactor,ridgecoef) ;
%     lpolyvar  --- Modified from lpolyd
%
%     last revised 10/12/95
%
%     Estimates the local variance (est = varsmooth) on xgrid
%
%     x = independent variable  (dim = n)
%     y = dependent variable  (dim = n)
%     hm = bandwidth for estimating the mean
%     hv = bandwidth for smoothing the squared residuals
%     k = degree of the local polynomials is 
%
%     This implementation uses the epan. kernel with support (-1,1).
%
%     returns:
%     f = the estimated order-th derivative of E(y|x) at each point 
%         on xgrid.  (m dimensional)
%     var = the estimate of the variance of this estimate divided by sigma2,
%           where sigma2 is the variance of the y's. (m dimensional)
%
%     
%     GLOBAL: resvar yyhatcov
%
%     calls the following functions:  rows, cols	
%
%    USAGE: varsmooth=lpolyvar(x,y,hm,hv,xgrid,k,varyfactor,ridgecoef)
%
%
global resvar yyhatcov varsmoothprel fprel;
n = rows(x) ;


    if rows(hm) == 1 ;
    hm = hm*ones(n,1) ;
    end ;

    if rows(hv) == 1 ;
    hv = hv*ones(n,1) ;
    end ;


f = ones(n,1) ;
var = ones(n,1) ;
resvar = ones(n,1) ;
yyhatcov = ones(n,1) ;
   
    for i=1:n ;
    xc = x - x(i) ;
    w = (3/4)*(1 - (xc/hm(i)).^2).*(abs(xc/hm(i)) < 1) ;
    w = w ./ varyfactor ;
    xm = ones(n,1) ;
    
        for jj = 1:k ;
        xm = [xm,(xc.^jj)] ;
        jj = jj + 1;
        end ;

    w2 = w*ones(1,cols(xm)) ;
    ixwx = inv(xm'* (w2.*xm)) ;
    ixwxxw = ixwx*(w2.*xm)' ;
    beta = ixwxxw * y ;
    f(i) =  beta(1) ;
    cov = ixwxxw * ixwxxw' ;
    var(i) = cov(1,1) ;
    yyhatcov(i) = ixwxxw(1,i) ;
    resvar(i) = 1 - 2*yyhatcov(i) + var(i) ;
    end ;


 res2 =(y - f).^2 ;
fprel = f;
[varsmooth,vvar] = lpolydb(x,res2,hv,xgrid,0,1,varyfactor,ridgecoef) ;
[resvarsmooth,vvar] =lpolydb(x,resvar,hv,xgrid,0,1,varyfactor,ridgecoef) ;
varsmoothprel = varsmooth ;
varsmooth = varsmooth./resvarsmooth ;
