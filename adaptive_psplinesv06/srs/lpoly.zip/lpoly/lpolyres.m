function [res2,resvar]=lpolyres(x,y,h1,k,varyfactor,ridgecoef) ;
%
%     last revised 3/20,97
%
%     Estimates the local variance (est = varsmooth) on xgrid
%
%     x = independent variable  (dim = n)
%     y = dependent variable  (dim = n)
%     h1 = bandwidth for estimating the mean
%     k = degree of the local polynomials is 
%
%     This implementation uses the epan. kernel with support (-1,1).
%
%     returns:
%     res2 = squared residual at each point 
%         of x.  (n dimensional)
%     resvar = the estimate of the variance of the residual divided by sigma2,
%           where sigma2 is the variance of the y's. (n dimensional)
%
%     
%     GLOBAL: yyhatcov = cov. between y and yhat divided by sigma2
%
%     calls the following functions: 	
%
%    USAGE: varsmooth=lpolyres(x,y,h1,h2,xgrid,k,varyfactor,ridgecoef)
%
%
global yyhatcov;
n = size(x,1) ;


    if size(h1,1) == 1 ;
    h1 = h1*ones(n,1) ;
    end ;

    
f = ones(n,1) ;
var = ones(n,1) ;
resvar = ones(n,1) ;
yyhatcov = ones(n,1) ;
   
    for i=1:n ;
    xc = x - x(i) ;
    w = (3/4)*(1 - (xc/h1(i)).^2).*(abs(xc/h1(i)) < 1) ;
    w = w ./ varyfactor ;
    xm = ones(n,1) ;
        if k > 0 ;
          for jj = 1:k ;
     	  xm = [xm,(xc.^jj)] ;
      	  jj = jj + 1;
          end ;
	end ;

    w2 = w*ones(1,size(xm,2)) ;
    ixwx = inv(xm'* (w2.*xm)) ;
    ixwxxw = ixwx*(w2.*xm)' ;
    beta = ixwxxw * y ;
    f(i) =  beta(1) ;
    cov = ixwxxw * ixwxxw' ;
    var(i) = cov(1,1) ;
    yyhatcov(i) = ixwxxw(1,i) ;
    resvar(i) = 1 - 2*yyhatcov(i) + var(i) ;
    end ;


 res2 =(y - f).^2 ;

