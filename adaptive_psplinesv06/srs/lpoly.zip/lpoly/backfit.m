function [mnew,Smat]=backfit(ycen,x,b,p,mstart,M1)

% Computes the additive model estimators mnew via backfitting for local
% polynomial smoothers of degree p, bandwidth vector b, using starting
% values mstart and cubic interpolation if n>M1
%
% Syntax: [mnew,Smat]=backfit(ycen,x,b,p,mstart,M1)
%
% where mnew is the additive component functions matrix and Smat the n by nD
% matrix of smoother matrices
%
%   Modified 12/9/96 by DR to handle case of only one x-variable
%   Modified 12/10/96 by DR to fix xgrid when x has negative values
%
% Uses: lpolyregh

if cols(x) == 1 ;
n = rows(x) ;
M=min(n,M1) ;
	if n>M1 ;
	grid=linspace(0,1,M);
	xgrid=ones(M,1)*(min(x) - 100*eps) + grid'*(max(x)-min(x) + 200*eps) ;
	else ;
	xgrid=x;
	end ;


Smat = lpolyregh(xgrid,x,b,p,0) ;
mnew = Smat*ycen ;
mnew = interp1(xgrid,mnew,x,'cubic') ;

else ;

%  Everything below here is as Jean wrote it

Countmax=30;

[n,D]=size(x);
M=min(M1,n);
if n>M1
	grid=linspace(0,1,M);
	xgrid=ones(M,1)*(min(x) - 100*eps) + grid'*(max(x)-min(x) + 200*eps) ;
else
	xgrid=x;
end
Smat=[];
for i=1:D
	eval(['S',int2str(i),'=lpolyregh(xgrid(:,i),x(:,i),b(i),p(i),0);'])
	eval(['Smat=[Smat S',int2str(i),'];'])
end

step=1;
mnew=mstart;
count=1;

if n>M1

while (step > 0.001 & count < Countmax)
mold=mnew;
for i=1:D
	S=eval(['S',int2str(i)]);
	mnewgrid=S*(ycen-sum(mold')'+mold(:,i));
	mnew(:,i)=interp1(xgrid(:,i),mnewgrid,x(:,i),'cubic');
end
mnew=mnew-ones(n,1)*sum(mnew)/n;
step=sum(sum((mnew-mold).^2))/n;
count=count+1;
end

else

while (step > 0.001 & count < Countmax)
mold=mnew;
for i=1:D
	S=eval(['S',int2str(i)]);
	mnew(:,i)=S*(ycen-sum(mold')'+mold(:,i));
end
mnew=mnew-ones(n,1)*sum(mnew)/n;
step=sum(sum((mnew-mold).^2))/n;
count=count+1;
end

end

if(count==Countmax)
'*** WARNING: count exceeded, backfitting converges slowly ***'
'Squared difference is still'
step
end

end;
