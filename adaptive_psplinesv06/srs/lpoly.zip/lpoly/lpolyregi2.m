function [yhatgrid,h,theta11,variance]=lpolyregi2(y,x,xgrid,p)

% This function computes the local polynomial fit of degree p (odd) for
%
%             y=m(x)+e,
%
% where e are assumed iid independent, on a set of points xgrid.
%
% Syntax: [yhatgrid,h,theta11,variance]=lpolyregi2(y,x,xgrid)
%
% Uses: backfit, lpolyreg, polyreg, fact, constants

% Initialization (sets the meta-parameters)

p=1;

%     numbin is the number of bins into which the observations are distributed
%     for each covariate, which is used in the computation of a minimum "safe"
%     bandwidth to avoid singularity
%                                           (should normally not be adjusted)
%     marg is the inflation factor used to increase the minimum "safe"
%     bandwidth
%                                   (can be increased in case of singularity)

numbin=500;
marg=0.2;

%    Cmax is the maximum number of iterations in the search for the optimum
%    number of "pieces" for the piecewise polynomial regression
%                                           (should normally not be adjusted)
%    Nmax is the maximum number of pieces for each covariate
%                                   (can be decreased in case of singularity)

Cmax=10;
Nmaxtheta=7;
M1=100;

%    alpha is the proportion of each boundary that is ignored in the
%    computation of theta
%                               (can be increased if plot of theta displays
%                                              instability at the boundaries)

alpha=0.05;

% Compute the constants for the bandwidth estimators for local polynomial
% degree p

cst=constants(p);

% Compute the minimum "safe" bandwidths for theta (bmg), variance (bmh)
% and m (bmh)

[n,D]=size(x);
if n<=D
	'*** matrix x has more covariates than observations ***'
	'*** possible transpose error? ***'
	stop
end
numbin=n*(n<=numbin)+numbin*(n>numbin);
Nmax= max(min(fix(n/(D*20)),Nmax),1);
ybar=sum(y)/n;
rx=max(x)-min(x);

bmg=zeros(1,D);
bmh=bmg;
if max(size(p))==1
	p=p*ones(1,D);
	cst=cst*ones(1,D);
end

for i=1:D
	[nn,xx]=hist(x(:,i),numbin);
	xx=xx(find(nn~=0))';
	nn=max(size(xx));
	temp=sort(xx(1:nn-p(i)-3)-xx(p(i)+4:nn));
	bmg(i)=-temp(1)*(1+marg);
	temp=sort(xx(1:nn-p(i)-1)-xx(p(i)+2:nn));
	bmh(i)=-temp(1)*(1+marg);
end

% Find initial values of sigma2 and theta13 by piecewise polynomial
% regression of degree p+3

pp=[];
xx=[];
for i=1:D
	for j=1:Nmaxtheta
		tempo=zeros(n,1);
		for jj=1:j
			temp=(x(:,i) <= min(x(:,i))+jj/j*rx(i));
	eval(['xx',int2str(i),int2str(j),'=[xx',int2str(i),int2str(j),' x(:,i).*(temp-tempo)];'])
			tempo=temp;
			eval(['pp',int2str(i),int2str(j),'=[pp',int2str(i),int2str(j),' p(i)];'])
		end
	end
	eval(['xx=[xx xx',int2str(i),int2str(Nmaxtheta),'];'])
	eval(['pp=[pp pp',int2str(i),int2str(Nmaxtheta),'];'])
end

yhat=polyreg(y,xx,pp+3);
rsmax=sum((yhat-y).^2);
dfmax=(sum(p)+3*D)*Nmaxtheta;
rs=zeros(1,Nmaxtheta);
minvec=zeros(1,D);
minvecnew=ones(1,D);
count=0;
xx=x;
pp=p;

while (any(minvecnew~=minvec) & count < Cmax)
  xxs=[];
  pps=[];
  yhat=polyreg(y,xx,pp+3);
  rsm=sum((yhat-y).^2);
  minvec=minvecnew;
  minvecs=[0 cumsum(minvec)];
  for i=1:D
    for j=1:Nmaxtheta
      if j==minvec(i)
        rs(j)=rsm;
      else
        minl=minvecs(i);
        maxl=minvecs(i+1)+1;
        tot=minvecs(i+1);
        eval(['xxt=[xx(:,1:minl) xx',int2str(i),int2str(j),' xx(:,maxl:tot)];'])
        eval(['ppt=[pp(:,1:minl) pp',int2str(i),int2str(j),' pp(:,maxl:tot)];'])
        yhat=polyreg(y,xxt,ppt+3);
        rs(j)=sum((yhat-y).^2);
      end
    end

df=(p(i)+3)*linspace(1,Nmaxtheta,Nmaxtheta)+minvec*(p'+3)-minvec(i)*(p(i)+3)
;
    Cp=rs/n+2*(1+df)/n*rsmax/(n-1-dfmax);
    [Cpmin,jmin]=min(Cp);
    minvecnew(i)=jmin;
    eval(['xxs=[xxs xx',int2str(i),int2str(jmin),'];'])
    eval(['pps=[pps pp',int2str(i),int2str(jmin),'];'])
  end
  xx=xxs;
  pp=pps;
  count=count+1;
end

if count==Cmax
'*** Cp count exceeded ***'
end

[yhat,beta]=polyreg(y,xx,pp+3);
df=max(size(beta))-1;
residP=y-yhat;
sigma2P=sum(residP.^2)/(n-1-df)

mstart=zeros(size(x));
theta1=zeros(size(x));
theta3=zeros(size(x));
beta(1)=[];
for i=1:D
	for j=1:minvecnew(i)
		btemp1=beta(p(i)+1:p(i)+3);
		p1=fact(linspace(p(i)+1,p(i)+3,3)')./fact([0 1 2]');
		btemp1=btemp1.*p1;
		btemp3=beta(p(i)+3);
		p3=fact(p(i)+3);
		btemp3=btemp3.*p3;
		Dp=[(xx(:,1)~=0)];
		theta3(:,i)=theta3(:,i)+Dp*btemp3;
		Dp=[Dp xx(:,1) xx(:,1).^2];
		theta1(:,i)=theta1(:,i)+Dp*btemp1;
		binit=[0; beta(1:p(i)+3)];
		for k=3:p(i)+3
			Dp=[Dp xx(:,1).^k];
		end
		mstart(:,i)=mstart(:,i)+Dp*binit;
		beta(1:p(i)+3)=[];
		xx(:,1)=[];
	end
end

theta13=sum(theta1.*theta3)/n

% Compute theta11 through local polynomial regression
% of degree p+2

g=cst(2,:)+(cst(3,:)-cst(2,:)).*(theta13>0);
g=g.*(sigma2P*rx./abs(theta13)/n).^(1./(2*p+5))
for i=1:D
	if g(i)<bmg(i)
		'*** warning: element of g is being replaced ***'
		i, g(i), bmg(i)
		g(i)=bmg(i);
	end
end

thet=zeros(n,D);
clip=thet;
minlim=min(x)+alpha*rx;
maxlim=max(x)-alpha*rx;
if(n>M1)
	grid=linspace(0,1,M1);
	xgridtemp=ones(M1,1)*min(x)+grid'*rx;
	for i=1:D
		temp=lpolyreg(xgridtemp(:,i),x(:,i),g(i),p(i)+2,p(i)+1)*y;
		thet(:,i)=interp1(xgridtemp(:,i),temp,x(:,i),'cubic');
		clip(:,i)=(minlim(i)<x(:,i)).*(x(:,i)<maxlim(i));
	end
else
	xgridtemp=x;
	for i=1:D
		thet(:,i)=lpolyreg(xgridtemp(:,i),x(:,i),g(i),p(i)+2,p(i)+1)*y;
		clip(:,i)=(minlim(i)<x(:,i)).*(x(:,i)<maxlim(i));
	end
end
nn=sum(clip);
bias=thet;

thet=thet.*clip;
theta11=sum(thet.^2)./nn

% Compute variance

% Fit local polynomial with bandwidth hP(theta11,sigma2P) on binned data

k=cst(4,:).*(sigma2P*rx./theta11/n).^(1./(2*p+3))
for i=1:D
if k(i)<bmh(i)
'*** warning: element of kappa is being replaced ***'
i, k(i), bmh(i)
k(i)=bmh(i);
end
end

if(n>M1)
	grid=linspace(0,1,M1);
	xgridtemp=ones(M1,1)*min(x)+grid'*rx;
	for i=1:D
		temp=lpolyreg(xgridtemp(:,i),x(:,i),k(i),p(i),0)*y;
		fit(:,i)=interp1(xgridtemp(:,i),temp,x(:,i),'cubic');
	end
else
	xgridtemp=x;
	for i=1:D
		fit(:,i)=lpolyreg(xgridtemp(:,i),x(:,i),k(i),p(i),0)*y;
	end
end

variance=sum((y-fit).^2)/n

% Compute fit with local polynomials of degree p

h=cst(1,:).*(variance*rx./theta11/n).^(1./(2*p+3))
for i=1:D
	if h(i)<bmh(i)
		'*** warning: element of h is being replaced ***'
		i, h(i), bmh(i)
		h(i)=bmh(i);
	end
end

yhatgrid=lpolyreg(xgrid,x,h,p,0)*y;


