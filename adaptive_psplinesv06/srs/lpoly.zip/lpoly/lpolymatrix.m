function [f,smatrix]=lpolymatrix(x,y,h,k) ;
%     lpolymatrix  --- Modified from lpolydb
%
%     last revised 9/23/96
%
%     Computes a local polynomial fit at the data points and the
%     smoother matrix.  Uses a global bandwidth.
%
n = rows(x) ;
f = zeros(n,1) ;
smatrix = zeros(n,n) ;
   
    for i=1:n ;
    xc = x - x(i) ;
    w = (3/4)*(1 - (xc/h).^2).*(abs(xc/h) < 1) ;
    xm = ones(n,1) ;
    
        for jj = 1:k ;
        xm = [xm,(xc.^jj)] ;
        end ;
 
    w2 = (w)*ones(1,cols(xm)) ;
    xw = w2.*xm ;
    xwx = xm' * xw  ;

        if  rcond(xwx) <= 1e-20;
	smatrix(i,:)=1e14;f(i)=-999999;
	else;
        ixwx = inv(xm'* (xw)) ;
	beta = ixwx * xw' * y ;
	smatrix(i,:) = [1 zeros(1,k) ] * ixwx *xw' ;
	f(i) =  beta(1) ;
	end ;

    end ;

