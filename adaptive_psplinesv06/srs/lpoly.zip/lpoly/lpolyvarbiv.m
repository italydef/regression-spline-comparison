function varsmooth=lpolyvar(x,y,h1,h2,xgrid,k) ;
%     lpolyvar  --- Modified from lpolyd
%
%     last revised 3/4/95
%
%     Estimates the local variance (est = varsmooth) on xgrid
%
%     x = independent variable  (dim = n)
%     y = dependent variable  (dim = n)
%     h1 = bandwidth for estimating the mean
%     h2 = bandwidth for smoothing the squared residuals
%     k = degree of the local polynomials is 
%
%     This implementation uses the epan. kernel with support (-1,1).
%
%     returns:
%     f = the estimated order-th derivative of E(y|x) at each point 
%         on xgrid.  (m dimensional)
%     var = the estimate of the variance of this estimate divided by sigma2,
%           where sigma2 is the variance of the y's. (m dimensional)
%
%     
%     GLOBAL: resvar f var yyhatcov
%
%     calls the following functions:  rows, cols	
%
%    USAGE: varsmooth=lpolyvar(x,y,h1,h2,xgrid,k)
%
%
global f resvar var yyhatcov;
n = rows(x) ;


    if rows(h1) == 1 ;
    h1 = h1*ones(n,1) ;
    end ;

    if rows(h2) == 1 ;
    h2 = h2*ones(n,1) ;
    end ;


f = ones(n,1) ;
var = ones(n,1) ;
resvar = ones(n,1) ;
yyhatcov = ones(n,1) ;
   
    for i=1:n ;
    xc = x - x(i) ;
    w = (3/4)*(1 - (xc/h1(i)).^2).*(abs(xc/h1(i)) < 1) ;
    xm = ones(n,1) ;
    
        for jj = 1:k ;
        xm = [xm,(xc.^jj)] ;
        jj = jj + 1;
        end ;

    w2 = w*ones(1,cols(xm)) ;
    ixwx = inv(xm'* (w2.*xm)) ;
    ixwxxw = ixwx*(w2.*xm)' ;
    beta = ixwxxw * y ;
    f(i) =  beta(1) ;
    cov = ixwxxw * ixwxxw' ;
    var(i) = cov(1,1) ;
    yyhatcov(i) = ixwxxw(1,i) ;
    resvar(i) = 1 - 2*yyhatcov(i) + var(i) ;
    end ;


 res2 =(y - f).^2 ;

[varsmooth,vvar] = lpolydb(x,res2,h2,xgrid,0,1) ;
[resvarsmooth,vvar] =lpolydb(x,resvar,h2,xgrid,0,1) ;
varsmooth = varsmooth./resvarsmooth ;
