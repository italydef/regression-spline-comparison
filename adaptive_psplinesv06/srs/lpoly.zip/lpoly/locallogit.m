function [f,var]=locallogit(x,y,h,xgrid,p) ;
%     locallog  --- Modified from lpolydb
%
%     last revised 9/7/98
%
%     Estimates the derivative of a regression function (including the
%        0th derivative) by local polynomial logistic regression
%        on a grid called "xgrid".
%
%     x = independent variable  (dim = n)
%     y = dependent variable  (dim = n)
%     xgrid = points at which the fit is calculated  (dim = m)
%     h = bandwidth vector --- bandwidth at i-th xgrid point is
%         h(i) (If h is a scalar then it is expanded to be a constant
%         m-vector.) (dim h = 1 or m)
%     p = degree of the local polynomials is (order + k) [So, k=1 for
%         local linear fits to estimate a regression function.] (scalar)
%
%     This implementation uses the epan. kernel with support (-1,1).
%
%     returns:
%     f = the estimated order-th derivative of E(y|x) at each point 
%         on xgrid.  (m dimensional)          
%
%       USAGE:  [f,var]=locallogit(x,y,h,xgrid,order,k) ;
%
%     
%     calls the following functions:  logitreg	
%
n = size(x,1) ;
m = size(xgrid,1) ;

    if size(h,1) == 1 ;
    h = h*ones(m,1) ;
    end ;

f = zeros(m,1) ;
var = f ;
betastart = zeros(p+1,1)  ;
   
    for i=1:m ;
    xc = x - xgrid(i) ;
    w = (3/4)*(1 - (xc/h(i)).^2).*(abs(xc/h(i)) < 1) ;
    [beta,yhat,varmatrix] = logitreg(xc,y,betastart,w) ;
    f(i) = logistic(beta(1)) ;
    var(i) = varmatrix(1,1)* ( (f(i)*(1-f(i))).^2 ) ;  
    betastart = beta ;
    end ;

