function [mean,xgridmean,bandmean,var,xgridvar,bandvar]= ...
                 ebbsmvdef(x,y,order,string) ;
%
%    Last edited:  11/6/97
%
%
%  Calls ebbsmvparam with default values of
%  USAGE:  [mean,xgridmean,bandmean,var,xgridvar,bandvar]= ...
%              ebbsmvdef(x,y,order,string) ;
%
%
%		INPUT
%  x and y are the independend and dependent variable (n by 1)
%  order = order of derivative being estimated (default = 0)
%  string = string evaluated after the defaults have been set. (default is the
%	null string, i.e., '')
%           Ex:  'J1=0' changes the default for J1 and 'pmean=1' changes
%		  the default from local quadratic to local linear
%
%		OUTPUT
%  mean = estimated derivative of mean function
%  bandmean = bandwidths used for mean
%  var = estimated variance function
%  bandvar = bandwidth for var
%  xgridmean = grid that mean is calculated on
%  xgridvar = grid that var is calculated on
%
%  Calls these subroutines:  autob17, lpolydb, ebbsvar, lpolyres, bspan
%                            ebbsmvparam, lpolyvar, prebin
%
%	Copyright: David Ruppert
if nargin < 4 ;
string = ' ';
end ;
if nargin < 3 ;
order = 0 ;
end ;

msespan = 0 ;
bandspan = 4 ;
M1 = 14 ;
J1 = 1 ;
J2 = 2 ;
nterms = 2 ;
varyfactor = 1 ;
ridgecoef = 0 ;
nskip = 0 ;
pmean = 2 ;
pvar = 0 ;
minx=min(x) ;
maxx = max(x) ;

n = size(y,1) ; 
xgrid=linspace(minx,maxx,25)';
hm = bspan(x,x,8/n) ;
hmeana = bspan(xgrid,x,10/n) ;
hmeanb = bspan(xgrid,x,1.2) ;
hvara = bspan(xgrid,x,20/n) ;
hvarb = bspan(xgrid,x,1.5) ;
eval(string) ;


 [mean,bandmean,var,bandvar]=ebbsmvparam(x,y,hm,hmeana,hmeanb, ...
     hvara,hvarb,pmean,pvar,order,xgrid,msespan,M1,J1,J2,nterms,varyfactor, ...
     ridgecoef,nskip,bandspan) ;

xgridmean = linspace(minx,maxx,200)';
bandmean = interp1(xgrid,bandmean,xgridmean,'linear') ;

[mean,var2] = lpolydb(x,y,bandmean,xgridmean, ...
            order,pmean,varyfactor,ridgecoef) ;     % get mean on xgrid2


xgridvar = xgrid ;

