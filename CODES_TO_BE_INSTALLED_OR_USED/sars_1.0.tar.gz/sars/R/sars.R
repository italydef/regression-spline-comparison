
 
############################ SARS function
 
sars <- function(X, Y, degree =3, sd=0)
# X =  a vector of predictor,
# Y =  a vector of response,
# OPTIONAL ARGUEMENTS
# deg = an integer indicating the degree of splines, the default is cubic
#       splines,<-
# sd = the noise level in Y if known,  the default is unknown,
{
  ind <- 1
  N <- length(X)
  W <- rep(1, N)
  kts <- as.double(c(min(X), max(X), X))
  k <- as.integer(0)
  Fit <- as.double(Y)
  if(N != length(Y)) {
    cat("\n The length of x and y variables must match \n")
    ind <- 0 }
  if(degree > (N-2)) ind <- 1
  if(ind == 1) {
    RSFIT <- .C("SARS", Fit, kts, k, 
              as.integer(degree), as.double(X), as.double(Y), 
              as.double(W), as.integer(N), as.double(sd))
    Fit <- RSFIT[[1]]
    kts <- RSFIT[[2]]
    k <- RSFIT[[3]]
  } 
  if(ind > 0) {
    kts <-kts[1:(k+2)]
    RSFIT <- list(fit=Fit, knots=kts) 
    RSFIT  ## output fitted values and knots 
  } 
}   
