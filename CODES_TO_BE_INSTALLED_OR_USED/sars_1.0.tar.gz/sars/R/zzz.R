.First.lib <- function(libname, pkgname, where) {
    library.dynam("sars", pkgname, libname)
}
