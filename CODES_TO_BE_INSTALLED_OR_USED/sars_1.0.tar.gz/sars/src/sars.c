/*********************************************************************/
/*                                                                   */
/*     Copyright (c) 1998 by Shanggang Zhou                          */
/*     This program is free to use for non-commercial purpose only,  */
/*     and publications using SARS should reference the following    */
/*     paper:                                                        */
/*                                                                   */
/*     Zhou, S. and Shen, X. (1998). Spatially adaptive splines and  */
/*     accurate knots selection schemes. Tech. Report No. 626,       */
/*     Department of Statistics, The  Ohio State University.         */
/*                                                                   */
/*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>  
#define min(x,y) (((x) < (y)) ? (x) : (y))
#define max(x,y) (((x) < (y)) ? (y) : (x))

#define maxdf 8
#define BW 4
#define pi 3.14159265
#define CC 1.0
#define STOP 1

/***************************************************************************
 *  (c) Shanggang Zhou (2001)                                              *
 *  The program is an implementation of the spatially adaptive regression  *
 *  splines (SARS) methodology, discussed in                               *
 *  Shanggang Zhou and Xiaotong Shen (2001) " Spatially adaptive splines   *
 *  and accurate knots selection schemes", JASA.                           *
 *  You are free to use this program, for non-commercial purposes only,    *
 *  under the condition that                                               *
 *                          this note is not to be removed.                *
 **************************************************************************/

void BSBase(bs, x, kts, deg, k)
/* here, k is the number of internal knots and deg is the degree of spline */
int deg, k;  double bs[], x, kts[];

{
  double  c1, c2, *prevbs; int i, df; 

  df=deg+k+1; 
  
  if (deg == 0) {
    for(i=0; i < df; ++i) bs[i]=0;
    if((kts[0] <= x) && (x <= kts[k+1])) {
      i=0; while(kts[i] < x) ++i; i = max(0, i-1); 
      bs[i]=1.0; }
  } /* end if */

  else {
    prevbs = calloc(df, sizeof(double));
    BSBase(prevbs, x, kts, deg-1, k);
    bs[0] = max(0.0, (kts[1]-x)/(kts[1]-kts[0])*prevbs[0]);
    if ((k+deg) > 1) {
      for (i = 1; i < k+deg; ++i) {
	c1 = kts[min(i,k+1)]-kts[max(0,i-deg)];
	if(c1 >0) c1 = (x-kts[max(0,i-deg)])/c1; 
	c2 = kts[min(k+1,i+1)]-kts[max(0,i-deg+1)];
	if(c2 >0) c2 = (kts[min(k+1,i+1)]-x)/c2;
	bs[i] = (c1 * prevbs[i-1]) + (c2 * prevbs[i]);
      } /* for */
    } /* end of if */
    bs[deg+k] = max(0.0,(x-kts[k])/(kts[k+1]-kts[k]) * prevbs[k+deg-1]);   

    free(prevbs);
  } /* else */

} /* end of BSBase function */ 

/*********************************************************************/

double Percentile(XN, N, k)
/* find the k-th largest number in array XN */
double XN[]; int N, k;
{
  int i, n_l=0, n_r=0, m; 
  double *left, *right, temp, poc;

  if(N > 1) {
    left  = malloc(N*sizeof(double));
    right = malloc(N*sizeof(double));

    temp = XN[k-1];  n_l=0;  n_r=0;
    if(N > k)  XN[k-1] = XN[N-1];   /* swap XN[k-1] and XN[N-1] */
    for(i=0; i < (N-1); ++i) {
      if(XN[i] < temp) {
        left[n_l] =XN[i]; n_l +=1; }
      else {
        right[n_r]=XN[i]; n_r +=1; }
    } /* end of for */
    
    if(k == (n_l+1)) poc = temp;    
    else {
      if(k > n_l) 
        poc = Percentile(right, n_r, k-n_l-1);
      else
        poc = Percentile(left, n_l, k);
    }
    free(left); free(right);
  }
  else poc = XN[0];

  return poc;

} /* end of Percentile */

/********************************************************************/

double SD_Est(Xn, Yn, n)
double Xn[], Yn[]; int n;

{

  double *abdif, *temp, med; int i, J;

  abdif = calloc(n, sizeof(double));
  temp  = calloc(n, sizeof(double));

  J=n-1;
  for(i=0; i< J; ++i)  abdif[i]=fabs(Yn[i]-Yn[i+1])/sqrt(2.0);  

  med = Percentile(abdif, J, n/2+1);  /* compute the 50-th percentile */
  med = med/.6745;

  free(abdif);  free(temp);

  return med;

} /* estimation the SD */

/******************************************************************/

void Sort_Rank(t, rank, len)
/* sort t and y according to t from the smallest to the alrgest */
double t[];  int rank[], len;

{

  double tmp_t;  int i, tmp_rank, n, change;

  n =len -1; change = n;
  while (change > 0) {

    change = 0;
    for(i = 0;i < n; ++i) {
      if (t[i] > t[i+1]) {
        tmp_t = t[i]; tmp_rank =rank[i];
        t[i] = t[i+1]; rank[i]=rank[i+1];
        t[i+1] = tmp_t; rank[i+1]=tmp_rank;
        change = i; } /* if */
    } /* for */
    n = change;
  } /* while */

}  /* end of Sort_Rank */

/***********************************************************************/

void XTY_XTX(xty, G, kts_ind, k, deg, N, XN, YN, W)
/* compute X^{'}Y in the spline regression */
double xty[], G[][maxdf], XN[], YN[], W[]; int kts_ind[], k, deg, N;

{
  int i, j, m, n, sub_k, sub_start, df, end, M; 
  double *kts, *nbs, *WY, *W2, *sub_kts, *temp;

  df = k+deg+1; M = deg+1; sub_start = 0; sub_k=k;
  kts = malloc((k+2)*sizeof(double)); 
  nbs = malloc(df*sizeof(double)); 
  WY  = malloc(N*sizeof(double));
  W2  = malloc(N*sizeof(double));

  for(i=0; i < N; ++i) { WY[i] = W[i]*YN[i]; W2[i]=W[i]*W[i]; }
  for(i=0; i <= (k+1); ++i) kts[i] = XN[kts_ind[i]];

  for(i=0; i < df; ++i) {/* initialize  */
    xty[i]=0; for(j=0; j <= M; ++j) G[i][j]=0; 
  }  /* end of for */

  for(i=0; i <= k; ++i) {
    sub_start = max(0, i-deg);
    sub_k = min(k+1, i+deg+1) - sub_start-1;
    sub_kts = &kts[sub_start]; temp = &nbs[-sub_start];
    end = kts_ind[i+1]; if(i == k) end +=1;
    for(j=kts_ind[i]; j < end; ++j) {
      BSBase(nbs, XN[j], sub_kts, deg, sub_k);
      for(m=i; m < (i+M); ++m) {
	xty[m] += temp[m]*WY[j];
	for(n = m; n < (i+M); ++n)
	  G[m][n-m] += temp[m]*temp[n]*W2[j];
      } /* end of for */
    } /* end of for */
  } /* end of for */

  /* using ridge pretect against singularity */ 
  for(i=0; i < df; ++i) G[i][0] += min(0.000001, 0.1/(N*N)); 

  free(kts); free(nbs); free(WY); free(W2);

} /* end of MTA_XTY */


/******************************************************************/

void BM_SyMLDec(G, df, band, L)
double G[][maxdf], L[][maxdf]; int df, band;

{
  int i, j, m;  double sum;

  for(i=0; i < df; ++i)   /* initialize */
    for(j=0; j <= band; ++j) L[i][j]=0;
  
  for(j = 0; j < df; ++j) {
    sum = 0.0;
    if (j > 0)
      for (m = max(0,j-band); m < j; ++m) sum += L[m][j-m] * L[m][j-m];
    L[j][0] = sqrt(G[j][0] - sum);
    
    i=j+1;
    while(i < min(df, j+band)) {

      sum = 0.0;
      if (j > 0)
	for (m = max(0,i-band); m < j; ++m) sum += L[m][i-m] * L[m][j-m];

      L[j][i-j] = (G[j][i-j]-sum)/L[j][0];
      ++i;
    } /* while */
  } /* for */

} /* end of BM_SyMLDec */

/****************************************************************/

void Forward_Solve(coef, L, df, deg, xty)
/* use forward substitution to solve L*coef = xty */
double coef[], L[][maxdf], xty[]; int df, deg;

{
  int i, j; double sum;

  for(i=0; i < df; ++i) {
    sum =0;
    j=i-min(deg,i);
    while(j < i) {
      sum += coef[j]*L[j][i-j]; ++j;}
    coef[i] = (xty[i]-sum)/L[i][0];
  } /* end of for */

}  /* end of Forward_Solve */

/***************************************************************/

void Backward_Solve(coef, L, df, deg, xty)
/* use forward substitution to solve L*coef = xty */
double coef[], L[][maxdf], xty[]; int df, deg;

{
  int i, j; double sum;

  for(i= (df-1); i >= 0; --i) {
    sum =0;
    j=i+min(deg, df-1-i);
    while(j > i) {
      sum += coef[j]*L[i][j-i]; --j; } 
    coef[i] = (xty[i]-sum)/L[i][0];
  } /* end of for */

}  /* end of Backward_Solve */

/*****************************************************************/
 
double Fast_BSFit(coef, Y, T, n, W, kts_ind, k, deg)
/* fast fit the regression spline with weight W[i]  */
int  n, kts_ind[], k, deg; double coef[], T[], Y[], W[];
 
{
  int i, df, band;
  double *xty, (*G)[maxdf], (*L)[maxdf], sse_fit=0;
 
  df =k+deg+1;  band =deg+1; 
  xty = malloc(df*sizeof(double));
  G   = malloc(df*maxdf*sizeof(double));
  L   = malloc(df*maxdf*sizeof(double));  
 
  XTY_XTX(xty, G, kts_ind, k, deg, n, T, Y, W);
  BM_SyMLDec(G, df, band, L);  /* compute the Cholosky decomposition */
  Forward_Solve(coef, L, df, deg, xty); /* forward solve L*coef =xty */
  for(i=0; i < df; ++i) xty[i]= coef[i];
  for(i=0; i < df; ++i) sse_fit += coef[i]*coef[i];
  Backward_Solve(coef, L, df, deg, xty); /* backward solve L*coef =xty */
 
  free(xty); free(G); free(L);
 
  return sse_fit;
}  /* end of Fast_BSFit  */
 
/****************************************************************/

void SP_FIT(Y_fit, kts_ind, k, deg, N, XN, YN)
int kts_ind[], k, deg, N; double Y_fit[], XN[], YN[];

{
  int i, j, m, sub_start, sub_k, end,  M, df;
  double *kts, *sub_kts, *nbs, *sub_nbs;
  double *coef, *W, *sub_coef, sum;

  df=k+deg+1;   M =deg+1; 

  kts = malloc((k+2)*sizeof(double));
  nbs = malloc(df*sizeof(double));
  coef= malloc(df*sizeof(double));
  W   = malloc(N*sizeof(double));

  for(i=0; i<= (k+1); ++i) kts[i]=XN[kts_ind[i]];
  for(i=0; i< N; ++i) W[i]=1;

  sum = Fast_BSFit(coef, YN, XN, N, W, kts_ind, k, deg);

  for(i=0; i<= k; ++i) {
    end = kts_ind[i+1]; 
    if(i == k) end +=1; 
    for(j=kts_ind[i]; j < end; ++j) {
      sub_start = max(0, i-deg);
      sub_k = min(k+1, i+M) - sub_start-1;
      sub_kts = &kts[sub_start]; /* define the sub knots */
      BSBase(nbs, XN[j], sub_kts, deg, sub_k);
  
      m= min(deg, i);  sub_nbs = &nbs[m];
      sub_coef = &coef[sub_start+m]; 
      sum =0;
      for(m=0; m < M; ++m) sum += sub_coef[m]*sub_nbs[m];
      Y_fit[j]=sum;
    } /* end of for */
  } /* end of for */

  free(kts); free(nbs); free(coef); free(W);

}  /* end of SP_FIT */


/*****************************************************************/

int Add_Sub_Kts(m, sub_kts, sub_k,  n_ind, kts, deg, k, N)
/* the return value is the position for the first sub knot */
int *m, sub_kts[], *sub_k, n_ind,  kts[], deg, k, N;

{  

  int i, j, n, M, sub_start, sub_end, adjust, begin, end;

  n = (deg+1)/2; M= max(2*deg, deg+BW);

  begin = max(0,n_ind-M);  adjust=0;
  if((kts[begin+1]-kts[begin]) < n) adjust =1;
  sub_start= max(0, kts[begin]- adjust);  

  end=min(k+1, n_ind+1+M); adjust=0;
  if((kts[end]-kts[end-1]) < n) adjust =1;
  sub_end = min(N-1, kts[end]+adjust);

  *m = sub_end - sub_start+1;
  *sub_k= end-begin-1;
  
  for(j=0; j <= *sub_k; ++j)  /* define the sub kts */
    sub_kts[j] = kts[j+begin]-sub_start;
  sub_kts[0]=0; sub_kts[*sub_k+1]= *m-1;

  return sub_start;

} /* end of add_sub_Kts */


/*****************************************************************/

int Del_Sub_Kts(m, sub_kts, sub_k,  n_ind, kts, deg, k, N)
/* the return value is the position for the first sub knot */
int *m, sub_kts[], *sub_k, n_ind,  kts[], deg, k, N;

{  

  int i, j, n, M, sub_start, sub_end, adjust, begin, end;

  n = (deg+1)/2; M= max(2*deg, deg+BW);

  begin = max(0,n_ind-M);  adjust=0;
  if((kts[begin+1]-kts[begin]) < n) adjust =1;
  sub_start= max(0, kts[begin]- adjust);  

  end=min(k+1, n_ind+2+M); adjust=0;
  if((kts[end]-kts[end-1]) < n) adjust =1;
  sub_end = min(N-1, kts[end]+adjust);

  *m = sub_end - sub_start+1;
  *sub_k= end-begin-1;
  
  for(j=0; j <= *sub_k; ++j)  /* define the sub kts */
    sub_kts[j] = kts[j+begin]-sub_start;
  sub_kts[0]=0; sub_kts[*sub_k+1]= *m-1;

  return sub_start;

} /* end of del_sub_Kts */

/*********************************************************************/

void Kts_Sort(kts, len)
/* sort t and y according to t from the smallest to the alrgest */
int kts[], len;

{

  int i, tmp_t, change;

  change = 1;
  while (change ==1) {

    change = 0;
    for(i = 0;i < len-1; ++i) {
      if (kts[i] > kts[i+1]) {
        tmp_t = kts[i]; 
        kts[i] = kts[i+1];
        kts[i+1] = tmp_t;
        change = 1; } /* if */
    } /* for */
  } /* while */

}  /* end of sort */

/*****************************************************************/

int Knot_Insert(knot, new_kts, kts, len)  
/* Insert "knot" to knot sequence "kts" to form "new_kts" */  
int knot, new_kts[], kts[], len;

{
  int i, *temp;

  temp = calloc(len+2, sizeof(int));

  for(i=0; i <= (len+1); ++i) temp[i]=kts[i];
  i=0; 
  while(temp[i] < knot) { new_kts[i]=temp[i]; ++i; }
  new_kts[i]=knot; 
  while(i <= (len+1)) { new_kts[i+1]=temp[i]; ++i; }

  free(temp);

  return len+1;
} /* end of Knot_Insert */

/*****************************************************************/

int Knot_Delete(pos, new_kts, kts, len)  
/* Delete "kts[pos]" in knot sequence "kts" to form "new_kts" */  
int pos, new_kts[], kts[], len;

{
  int i, *temp;

  temp = calloc(len+2, sizeof(int));

  for(i=0; i<= (len+1); ++i) temp[i]=kts[i];
  for(i=0; i < pos; ++i) new_kts[i]=temp[i]; 
  for(i=pos; i <= len; ++i) new_kts[i]=temp[i+1];

  free(temp);

  return len-1;
} /* end of Knot_Insert */


/*****************************************************************/

double GCV(kts_ind, k, deg, N, XN, YN, SD)
/* for the given location and band computer the weight MSE */
/* here k is # of internal knots and n is  # of points in the range*/
double XN[], YN[], SD; int kts_ind[], k, deg, N;

{
  
  int i, df;
  double *coef, *W, sse_fit, gcv;
 
  df = deg+k+1;
  coef =calloc(df, sizeof(double));
  W   = malloc(N*sizeof(double));
 
  for(i=0; i< N; ++i) W[i]=1;
  sse_fit= Fast_BSFit(coef, YN, XN, N, W, kts_ind, k, deg);
 
  gcv = -sse_fit/(SD*SD*N)+(1+CC)*df/N; 
 
  free(coef); free(W);
 
  return gcv;

} /* end of GCV function */

/*******************************************************************/

double Fib_Search(opt_pos, ind, gcv, begin, end, kts, k, deg, N, XN, YN, SD)
int *opt_pos, ind, begin, end, kts[], k, deg, N; double gcv, XN[], YN[], SD;
{

  int dif, new_k, loc, opt_loc, *new_kts;
  double new_gcv, opt_gcv;

  new_kts =calloc(k+3, sizeof(int));
                   
  dif = end - begin; opt_gcv =gcv;
  loc = *opt_pos;
  if(ind == 1) loc = end - (loc-begin);
  else loc = begin + (end - loc);

  new_k=Knot_Insert(loc, new_kts, kts, k);  
  new_gcv = GCV(new_kts, new_k, deg, N, XN, YN, SD);

  if(gcv < new_gcv) {
    if(ind  == 1) end = loc; else begin =loc;
    ind = 3-ind;         /* switcth the ind  */
  }
  else {
    if(ind  == 1) begin = *opt_pos; else end = *opt_pos;
    *opt_pos = loc;  opt_gcv = new_gcv;   /* switcth the position */
  }

  if (dif > 3) 
    opt_gcv = Fib_Search(opt_pos, ind, opt_gcv, begin, end, kts, k, deg, N, XN, YN, SD);

  free(new_kts); 

  return opt_gcv;
} /* end of Fib_Search funciton */

/********************************************************************/

double Opt_Loc(opt_pos, n, begin, end, kts, k, deg, N, XN, YN, SD)
int *opt_pos, n, begin, end, kts[], k, deg, N; double XN[], YN[], SD;
{

  int i, m, dif, width, *fib, loc, *new_kts, new_k, ind=1; 
  double gcv[3], new_gcv, opt_gcv;

  fib = calloc(N, sizeof(int));
  new_kts = calloc(k+3, sizeof(int));

  width =end-begin;
  fib[0]=1; fib[1]=1; m=1;
  while(fib[m] < width) {          /* define the fib number sequence */
    fib[m+1]=fib[m]+fib[m-1]; ++m; 
  }

  if(width < 3) {                 
    loc = (begin+end)/2; 
    new_k=Knot_Insert(loc, new_kts, kts, k);  
    opt_gcv = GCV(new_kts, new_k, deg, N, XN, YN, SD);
    *opt_pos =loc;
  }
  else {
    if(width < fib[m]) {       /* adjust the interval if necessary */
      dif = width - fib[m-1]; 
      loc = begin+ dif;
      new_k=Knot_Insert(loc, new_kts, kts, k);  
      gcv[1] = GCV(new_kts, new_k, deg, N, XN, YN, SD);
      
      loc = end -dif;
      new_k=Knot_Insert(loc, new_kts, kts, k);  
      gcv[2] = GCV(new_kts, new_k, deg, N, XN, YN, SD);

      if(gcv[1] > gcv[2]) begin = begin+ dif; 
      else end = end -dif;
      m = m-1;              
    }    /* end of if */

    loc = end-fib[m-1];
    new_k=Knot_Insert(loc, new_kts, kts, k);
    new_gcv = GCV(new_kts, new_k, deg, N, XN, YN, SD);
    *opt_pos = loc;
    opt_gcv=Fib_Search(opt_pos, ind, new_gcv, begin, end, kts, k, deg, N, XN, YN, SD);
  }   /* end of else */
  
  free(fib); free(new_kts);

  return opt_gcv;
}   /* end of function Opt_Loc  */

/*******************************************************************/

int Kts_Add(add_kts, ind, k, deg, N, XN, YN, SD)
int add_kts[], ind[], k, deg, N; double XN[], YN[], SD;

{
  int n, m, i, j, opt_loc, *new_ind, add_k, begin, end;
  int  n_ind, temp_ind, *sub_kts, sub_k, sub_start,  dif, sum;
  double gcv, old_gcv, *Xm, *Ym;

  sub_kts =calloc(2*(k+2), sizeof(int));
  new_ind =calloc(2*(k+2), sizeof(int));

  n = 1;  n_ind=0; add_k =k;

  for(i=0; i <= k; ++i) {
    sum =0;
    if(i >0) 
      for (j=max(0,n_ind-n); j < n_ind; ++j) sum += new_ind[j]; 
    for (j=i; j <= min(i+n, k); ++j) sum += ind[j]; 
       
    dif =add_kts[n_ind+1]-add_kts[n_ind]; /* # pts in center interval */
     
    if((sum > 0) && (dif > STOP)) {  
      /* define the subset of data */
      sub_start=Add_Sub_Kts(&m,sub_kts,&sub_k,n_ind,add_kts,deg,add_k,N);
      Xm = &XN[sub_start]; Ym = &YN[sub_start];
      old_gcv = GCV(sub_kts, sub_k, deg, m, Xm, Ym, SD);
    
      begin = add_kts[n_ind]-sub_start; 
      end = add_kts[n_ind+1]-sub_start; 
      n=1; 
      gcv=Opt_Loc(&opt_loc,n,begin,end,sub_kts,sub_k,deg,m,Xm,Ym,SD);
      
      if(old_gcv > gcv) {
	opt_loc +=sub_start;
	add_k = Knot_Insert(opt_loc, add_kts, add_kts, add_k);
	if(n_ind > 0) new_ind[n_ind-1]= max(new_ind[n_ind-1], 1); 
	new_ind[n_ind]=2; n_ind +=1;
	new_ind[n_ind]=1; n_ind +=1;  
      } /* end of if */
      else {
	new_ind[n_ind]=0; n_ind +=1; }
    } /* end of if */
    else {
      new_ind[n_ind]=0; n_ind +=1; }
  } /* end of for */

  for(i=0; i <= add_k; ++i) ind[i]= new_ind[i];

  free(sub_kts); free(new_ind);

  return add_k;

} /* end of Kts_Add function */


/**************************************************************************/

int Kts_Adjust(adjust_kts, ind, k, deg, N, XN, YN, SD)
int adjust_kts[], ind[], k, deg, N; double XN[], YN[], SD;

{
  int n, m, i, j, I, J,  opt_loc, new_k, adjust_k, old_k, begin, end;
  int *new_kts, *new_ind, n_ind, temp_ind;
  int *sub_kts, sub_k, sub_start, M, sum;
  double gcv[3], old_gcv, *Xm, *Ym;

  sub_kts =calloc(k+2, sizeof(int));
  new_ind =calloc(k+2, sizeof(int));
  new_kts =calloc(k+2, sizeof(int));

  n = 1; M= max(2*deg, deg+BW); n_ind=0; adjust_k = k; 

  for(I=1; I <= 3; ++I) {
    n_ind=0; old_k = adjust_k; 
    J=I; if(I > 2) J=0;
    for(i=0; i < old_k; ++i) { 
      sum = ind[max(0,i-1)]+ind[i]+ind[i+1];
      if((ind[i] == J) && (sum >0)) {
	sub_start=Del_Sub_Kts(&m,sub_kts,&sub_k,n_ind,adjust_kts,deg,adjust_k,N);
	Xm = &XN[sub_start]; Ym = &YN[sub_start];

	old_gcv = GCV(sub_kts, sub_k, deg, m, Xm, Ym, SD);

	/* compute GCV with the deleted knot */
	temp_ind = n_ind - max(0,n_ind-M)+1;
	new_k=Knot_Delete(temp_ind, new_kts, sub_kts, sub_k); 
	gcv[0] = GCV(new_kts, new_k, deg, m, Xm, Ym, SD); 

      	/* compute GCV with the adjusted knot */
	n=1;  begin = new_kts[temp_ind-1]; end = new_kts[temp_ind];
	gcv[1] = Opt_Loc(&opt_loc, n, begin, end, new_kts, new_k, deg, m, Xm, Ym, SD);
     
	if(gcv[0] >= min(gcv[1], old_gcv)) {

	  if(gcv[1] < min(gcv[0], old_gcv)) 
	    adjust_kts[n_ind+1]=opt_loc + sub_start; 
	  new_ind[n_ind]=ind[i]; n_ind +=1;  
	} /* end of if */
	else 
	  adjust_k=Knot_Delete(n_ind+1, adjust_kts, adjust_kts, adjust_k);
      } /* end of if */
      else { new_ind[n_ind] = ind[i]; n_ind +=1; }
    } /* end of for */
    for(i=0; i < adjust_k; ++i) ind[i]= new_ind[i];
    ind[adjust_k]=ind[k];
  } /* end of for */

  free(sub_kts); free(new_ind); free(new_kts);

  return adjust_k;

} /* end of Kts_Adjust function */

/****************************************************************************/

int Mix_Search(add_kts, k, deg, N, XN, YN, SD)
int add_kts[], k, deg, N; double XN[], YN[], SD;

{
  int i, j, n_r=2, m, change, old_k, new_k, *ind, *old_kts;

  ind =calloc(N, sizeof(int));
  old_kts =calloc(N, sizeof(int));

  old_k=k;  old_kts[0]=0;
  for(i=0; i <= old_k; ++i) ind[i]=1;
  old_k = Kts_Add(add_kts, ind, old_k, deg, N, XN, YN, SD);
  for(i=0; i <= old_k; ++i)  old_kts[i]=add_kts[i];

  for(i=0; i < n_r; ++i) {
    for(j=0; j <= old_k; ++j) ind[j]=max(ind[j],1);
    if(k > 1)
      old_k = Kts_Adjust(add_kts, ind, old_k, deg, N, XN, YN, SD);
    if((i > 0) && (k > 1))
      old_k = Kts_Adjust(add_kts, ind, old_k, deg, N, XN, YN, SD);

    change=1; m =old_k;
    while (change == 1) {
      new_k = Kts_Add(add_kts, ind, old_k, deg, N, XN, YN, SD);
      if(new_k == old_k) change =0;
      else {
	new_k = Kts_Adjust(add_kts, ind, new_k, deg, N, XN, YN, SD); 
	if(i > 0)
	  new_k = Kts_Adjust(add_kts, ind, new_k, deg, N, XN, YN, SD); 
      }

      old_k = new_k; change =0;
      for(j=1; j <= old_k; ++j) {
	if(add_kts[j] != old_kts[j]) {
	old_kts[j] = add_kts[j]; change =1; }
      } /* end of for */
      m = max(new_k, m+1);
      if((m-new_k) > max(4, new_k/5))  change =0;  /* force selection end */ 
    } /* end of while */
  } /* end of for */

  free(ind); free(old_kts);

  return new_k;

} /* end of function Mix_Search */


/********************************************************************/
int Sub_Set(sub_kts, del_kts, del_k, kts, k, deg)
/* get subset of knots by deleting knots at del_kts[] from kts[] */
int sub_kts[], del_kts[], del_k, kts[], k, deg;
{
  int i, j, sub_k;
         
  for(i=0; i < del_kts[0]; ++i)
    sub_kts[i] = kts[i];
  
  sub_k = del_kts[0];
  if(del_k > 1)
    for(j=0; j < (del_k-1); ++j)  
      for(i=del_kts[j]+1; i < del_kts[j+1]; ++i) {
        sub_kts[sub_k] = kts[i];
        sub_k +=1;
      }
  
  for(i=del_kts[del_k-1]+1; i <= (k+1); ++i) {
    sub_kts[sub_k] = kts[i];
    sub_k +=1;
  }
  
  sub_k = k - del_k;

  return sub_k;

} /* end of function sub_Set */

/*********************************************************************/

int Knot_Initialize(init_kts, deg, N, XN, YN, SD)
/* select the initial knots for knot selection */
int init_kts[], deg, N; double XN[], YN[], SD;

{
  int i, j, n, M, k, new_k, *new_kts, old_k, *old_kts, *ind, *old_ind; 
  int *sub_kts, sub_k, *del_kts, del_k, begin, end, if_complete, pos;
  int *l_kts, l_k, *r_kts, r_k;
  double *new_fit, *sub_fit,  dif, sse;
  double *l_fit, *r_fit, l_sse, r_sse, min_sse;
  double n_sse, nl_sse, nr_sse, chi[30], threshold;

  chi[0] = 7.879; chi[1] = 9.210; chi[2] = 11.34; chi[3] = 13.28;
  chi[4] = 15.09; chi[5] = 16.81; chi[6]= 18.48; chi[7] = 20.09;
  chi[8] = 21.67; chi[9] = 23.21; chi[10] = 24.72; chi[11] = 26.22;
  chi[12]= 27.69; chi[13]= 29.14; chi[14] = 30.58; chi[15] = 32.00;
  chi[16]= 33.41; chi[17]= 34.81; chi[18] = 36.19; chi[19] = 37.57;

  new_kts = calloc(N, sizeof(int));
  old_kts = calloc(N, sizeof(int));
  sub_kts = calloc(N, sizeof(int));
  del_kts = calloc(N, sizeof(int));
  l_kts = calloc(N, sizeof(int));
  r_kts = calloc(N, sizeof(int));
  ind = calloc(N, sizeof(int));
  old_ind = calloc(N, sizeof(int));
  new_fit = calloc(N, sizeof(double));
  sub_fit = calloc(N, sizeof(double));
  l_fit = calloc(N, sizeof(double));
  r_fit = calloc(N, sizeof(double));

  M = 2*(deg+1)+1;

  new_k = N-2;
  for(i=0; i <= (new_k+1); ++i) {
    new_kts[i] = i;  ind[i] = 0; } 
  
  ind[0] =2; ind[new_k+1] = 2;     /* protect end knots from deletion */  

  if_complete =0;
  while(if_complete == 0) {

  if(new_k <= (deg+1))  if_complete =1;

  pos =0;      /* pos =0 implies start from left,  otherwise from right */
  while(if_complete == 0) {  /* repeat deletion if more knots not tested */
    
    if(pos == 0) {
      i=2; del_k=0;           /* select candidate knots from left to right */
      while (i < new_k)      
        if(ind[i] == 0) {     /* indicate knot[i] to be tested for deletion */
          del_kts[del_k]=i; del_k +=1; 
          i += M;
        }
        else i +=1;
      pos = 1;
    }  /* end of if */
    else {
      i=new_k-1; sub_k=0;      /* select candidate knots from right to left */
      while (i > 1)      
        if(ind[i] == 0) {     /* indicate knot[i] to be tested for deletion */
          sub_kts[sub_k]=i; sub_k +=1; 
          i += -M;
        }
        else i += -1;

      del_k = sub_k;
      for(i=0; i < del_k; ++i)
        del_kts[i] = sub_kts[sub_k-1-i];
      
      pos = 0;
    }  /* end of else */

    if((del_k > 0) && (new_k > (deg+1))) {                  
      
      sub_k = Sub_Set(sub_kts, del_kts, del_k, new_kts, new_k, deg);

      /* printf("sub = %d del = %d k = %d\n", sub_k, del_k, new_k); */

      for(j=0; j < del_k; ++j)  del_kts[j] += -1;
      l_k = Sub_Set(l_kts, del_kts, del_k, new_kts, new_k, deg);

      for(j=0; j < del_k; ++j)  del_kts[j] += 2;
      r_k = Sub_Set(r_kts, del_kts, del_k, new_kts, new_k, deg);

      for(j=0; j < del_k; ++j)  del_kts[j] += -1;  

      SP_FIT(new_fit, new_kts, new_k, deg, N, XN, YN);
      SP_FIT(sub_fit, sub_kts, sub_k, deg, N, XN, YN);
      SP_FIT(l_fit, l_kts, l_k, deg, N, XN, YN);
      SP_FIT(r_fit, r_kts, r_k, deg, N, XN, YN);

      k =0;
      for(j=0; j < del_k; ++j) {
        begin = new_kts[max(0, del_kts[j]-M/2-1)];
        end   = new_kts[min(new_k+1, del_kts[j]+M/2+1)];
        sse =0; l_sse =0; r_sse =0;
        for(n=begin; n <= end; ++n) {
          dif = new_fit[n] - sub_fit[n];     sse += dif*dif;
          dif = new_fit[n] - l_fit[n];       l_sse += dif*dif;
          dif = new_fit[n] - r_fit[n];       r_sse += dif*dif;
        }  /* end of for */

        i = del_kts[j];
        ind[i] = max(ind[i], 1); 
        ind[i-1] = max(ind[i-1], 1); 
        ind[i+1] = max(ind[i+1], 1);

        n = (new_kts[i+1]-new_kts[i-1]+1)/2;  
        n_sse =   sse/chi[min(n,6)-1];

        n = (new_kts[i]-new_kts[i-2]+1)/2;   
        nl_sse = l_sse/chi[min(n,6)-1];

        n = (new_kts[i+2]-new_kts[i]+1)/2;   
        nr_sse = r_sse/chi[min(n,6)-1];
       
        min_sse = min(n_sse, min(nl_sse, nr_sse)); 
        if(min_sse < SD*SD) {
          min_sse = min(sse, min(l_sse, r_sse)); 
          if(min_sse == l_sse) sub_kts[k]=i-1;
          if(min_sse == sse)   sub_kts[k]=i;
          if(min_sse == r_sse) sub_kts[k]=i+1;
          k +=1;
        } /* end of if */
        else {
          ind[i] = 2;
        } /* end of else */
      }  /* end of for */

      del_k =k; old_k = new_k;
      if(del_k > 0) {
        for(j=0; j < del_k; ++j)        del_kts[j]=sub_kts[j];
        for(i=0; i<= (new_k+1); ++i) {
          old_kts[i] = new_kts[i]; old_ind[i] = ind[i]; 
        } /* end of for */

        new_k = Sub_Set(new_kts, del_kts, del_k, old_kts, old_k, deg);
        new_k = Sub_Set(    ind, del_kts, del_k, old_ind, old_k, deg);
      } /* end of if */
    }   /* end of if */
    else if_complete = 1;

  } /* end of while */

  if_complete = 1;
  
  for(i=0; i<= (new_k+1); ++i) old_ind[i] = ind[i]; 
  for(i= 2; i < new_k; ++i) 
    if(old_ind[i] < 2) { 
      ind[i] = 0;     
      if_complete = 0; } 

  if(new_k <= (deg+1)) if_complete = 1;

  } /* end of while */

  for(i=0; i <= new_k +1; ++i)  init_kts[i] = new_kts[i];

  free(new_kts); free(old_kts); free(sub_kts); free(del_kts); 
  free(ind); free(old_ind); free(new_fit); free(sub_fit);
  free(l_kts); free(r_kts); free(l_fit); free(r_fit);

  return new_k;

} /* end of function Knot_Initialize */

/********************************************************************/

int Quick_Select(kts, deg, N, XN, YN, SD)
/* select the knots for regression */
int deg, N, kts[]; double XN[], YN[], SD;

{
  int i, j, n_kts;
  int n_init, *init_kts;

  init_kts = calloc(N, sizeof(int));

  n_init = Knot_Initialize(init_kts, deg, N, XN, YN, SD);

  n_kts=Mix_Search(init_kts, n_init, deg, N, XN, YN, SD);

  for(i=0; i <= (n_kts+1); ++i) kts[i] = init_kts[i];

  free(init_kts);

  return n_kts;

}  /* end if Quick_Select */

/**********************************************************************/

void SARS(Fit, knots, kp, degp, X, Y, W, Np, SD)
long *kp, *Np, *degp; 
double knots[], Fit[], X[], Y[], W[], *SD;

{
  int i, k, N, deg, *kts, *rank;
  double  *XN, *YN, *temp, *rw, sigma, code[5], sum;

  N = (int) (*Np); deg= (int) (*degp);  sigma = *SD;

  if(deg > (maxdf-3)) {
    deg =3;
    printf("\n The degree exceeded the the maximum degree %d ", maxdf-3);
    printf("\n The cubic splines are used in the regression \n");
  }  /* end of if */
  
  kts   = calloc(N, sizeof(int));
  rank  = calloc(N, sizeof(int));
  XN    = calloc(N, sizeof(double));
  YN    = calloc(N, sizeof(double));
  temp  = calloc(N, sizeof(double));
  rw    = calloc(N, sizeof(double));  
  
  for(i=0; i < N; ++i) {
    rw[i] = sqrt(W[i]); XN[i] = X[i]; rank[i]=i;  temp[i] = Y[i]*rw[i];  
  }  

  Sort_Rank(XN, rank, N);
  for(i=0; i < N; ++i) YN[i]= temp[rank[i]];
  if(sigma == 0) sigma = SD_Est(XN, YN, N); 

  k=Quick_Select(kts, deg, N, XN, YN, sigma);  
   
  SP_FIT(temp, kts, k, deg, N, XN, YN);

  for(i=0; i < N; ++i) temp[i] = temp[i]/rw[rank[i]];
  for(i=0; i < N; ++i) Fit[rank[i]]=temp[i];

  for(i=0; i <= (k+1); ++i) knots[i]=XN[kts[i]];
  *kp= (long) k;

  free(kts); free(rank); free(XN); free(YN); free(temp); free(rw);

}
